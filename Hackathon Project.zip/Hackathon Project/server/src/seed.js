import { db, policiesCol } from "./services/firestore.js";

/* ------------------------------------------------------------------ */
/*  Mock Data                                                         */
/* ------------------------------------------------------------------ */

// Four realistic demo policies
const policies = [
  {
    id: "POLICY-001",
    policyHolder: "John Doe",
    mobile: "+11234567890",
    policyType: "Auto",
    claimId: "CLM-0001",
    date: "2024-05-15",
    claimCost: 1500,
    fraudDetected: false,
    redFlags: 1,
    summary: "The claimant reported a minor fender bender in a parking lot. The evidence includes photos of the damage and a police report. The claim appears straightforward with no initial signs of fraud.",
    fraudInfo: [],
  },
  {
    id: "POLICY-002",
    policyHolder: "Jane Smith",
    mobile: "+12345678901",
    policyType: "Auto",
    claimId: "CLM-0002",
    date: "2024-05-20",
    claimCost: 5000,
    fraudDetected: true,
    redFlags: 4,
    summary: "Claimant reported a staged accident with conflicting witness statements. The vehicle's damage is inconsistent with the description of the event. Multiple red flags detected.",
    fraudInfo: [
      "Inconsistent damage photos.",
      "Claimant's story changed during questioning.",
      "Third-party witness could not be reached.",
    ],
  },
  {
    id: "POLICY-003",
    policyHolder: "Alex Johnson",
    mobile: "+13456789012",
    policyType: "Home",
    claimId: "CLM-0003",
    date: "2024-06-01",
    claimCost: 25000,
    fraudDetected: false,
    redFlags: 0,
    summary: "The claimant reported water damage from a burst pipe. Submitted evidence includes a plumber's report and photos of the damage. All documentation appears to be in order.",
    fraudInfo: [],
  },
  {
    id: "POLICY-004",
    policyHolder: "Emily White",
    mobile: "+14567890123",
    policyType: "Auto",
    claimId: "CLM-0004",
    date: "2024-06-10",
    claimCost: 800,
    fraudDetected: false,
    redFlags: 2,
    summary: "Claim for a cracked windshield. The provided invoice from a reputable glass repair company confirms the replacement cost. No suspicious activity noted.",
    fraudInfo: [],
  },
];

// Mock evidence for each policy
const evidences = {
  "POLICY-001": [
    { name: "damage-photo-1.jpg", url: "https://storage.googleapis.com/team21-uploads/mock/damage1.jpg", summary: "Photo shows a dent on the rear bumper of the claimant's vehicle." },
    { name: "police-report.pdf", url: "https://storage.googleapis.com/team21-uploads/mock/report.pdf", summary: "Police report confirms a minor, non-injury accident at the specified location." },
  ],
  "POLICY-002": [
    { name: "inconsistent-damage.jpg", url: "https://storage.googleapis.com/team21-uploads/mock/damage2.jpg", summary: "Photo shows damage inconsistent with a low-speed collision, suggesting prior issues." },
    { name: "witness-statement.pdf", url: "https://storage.googleapis.com/team21-uploads/mock/report.pdf", summary: "Witness statement contradicts the claimant's description of the incident." },
  ],
  "POLICY-003": [
    { name: "water-damage.jpg", url: "https://storage.googleapis.com/team21-uploads/mock/damage3.jpg", summary: "Image shows significant water damage to the flooring and drywall in the living room." },
    { name: "plumber-invoice.pdf", url: "https://storage.googleapis.com/team21-uploads/mock/invoice.pdf", summary: "Invoice from 'Reliable Plumbing Co.' details the emergency repair of a burst pipe." },
  ],
  "POLICY-004": [
    { name: "cracked-windshield.jpg", url: "https://storage.googleapis.com/team21-uploads/mock/damage4.jpg", summary: "Clear photo of a large crack across the vehicle's windshield." },
    { name: "repair-invoice.pdf", url: "https://storage.googleapis.com/team21-uploads/mock/invoice.pdf", summary: "Invoice from 'AutoGlass Experts' for the full replacement of a windshield." },
  ],
};


// A collection of policy numbers and their corresponding mock OTPs
const otps = {
  "POLICY-001": "123456",
  "POLICY-002": "654321",
  "POLICY-003": "112233",
  "POLICY-004": "445566",
};

/* ------------------------------------------------------------------ */
/*  Seeding function                                                  */
/* ------------------------------------------------------------------ */

async function seedDatabase() {
  console.log("🔥 Deleting existing data...");
  // This is a simple way to clear collections for a clean seed.
  // For larger applications, you might use batch deletes.
  const policyDocs = await policiesCol.listDocuments();
  for (const doc of policyDocs) {
    // Delete subcollections first
    const evidenceCol = doc.collection('evidence');
    const evidenceDocs = await evidenceCol.listDocuments();
    await Promise.all(evidenceDocs.map(d => d.delete()));
    // Delete parent doc
    await doc.delete();
  }
  const otpDocs = await db.collection("otps").listDocuments();
  await Promise.all(otpDocs.map(d => d.delete()));
  console.log("✅ Existing data deleted.");


  console.log("\n🌱 Seeding database...");

  // Use a batch write for efficiency
  const batch = db.batch();

  // Seed policies and their evidence sub-collections
  for (const policy of policies) {
    const policyRef = policiesCol.doc(policy.id);
    batch.set(policyRef, policy);
    console.log(`  - Seeding policy ${policy.id}`);

    const policyEvidences = evidences[policy.id] || [];
    for (const evidence of policyEvidences) {
        const evidenceRef = policyRef.collection("evidence").doc();
        batch.set(evidenceRef, { ...evidence, uploadedAt: new Date() });
    }
  }

  // Seed OTPs
  const otpsCol = db.collection("otps");
  for (const [policyId, otp] of Object.entries(otps)) {
    const otpRef = otpsCol.doc(policyId);
    batch.set(otpRef, { otp });
    console.log(`  - Seeding OTP for ${policyId}`);
  }

  // Commit the batch
  await batch.commit();

  console.log("\n✅ Database seeded successfully!");
}

seedDatabase()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("❌ Error seeding database:", err);
    process.exit(1);
  });
