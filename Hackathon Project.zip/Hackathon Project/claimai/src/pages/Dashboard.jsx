import React, { useState, useEffect, useMemo } from "react";
import PropTypes from "prop-types";
import {
  FiFileText,
  FiAlertTriangle,
  FiDollarSign,
  FiShield,
  FiSearch,
  FiFile,
  FiVideo,
  FiPaperclip,
  FiDownload,
  FiClock,
  FiCheckCircle,
  FiCpu,
  FiTag,
  FiUser,
  FiInbox,
  FiTrendingUp,
  FiFlag,
} from "react-icons/fi";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

// --- HELPER FUNCTIONS ---

const formatCurrency = (amount) => {
  if (amount === null || amount === undefined) return "N/A";
  return new Intl.NumberFormat("de-DE", {
    style: "currency",
    currency: "GBP",
  }).format(amount);
};

const getFileIcon = (fileName) => {
  const extension = fileName?.split(".").pop().toLowerCase() || "";
  if (["jpg", "jpeg", "png", "webp", "gif"].includes(extension))
    return <FiFile className="text-blue-500" />;
  if (["mp4", "mov", "avi", "webm"].includes(extension))
    return <FiVideo className="text-purple-500" />;
  if (extension === "pdf") return <FiFileText className="text-red-500" />;
  return <FiPaperclip className="text-gray-500" />;
};

const formatDate = (dateString) => {
  if (!dateString?.seconds) return "N/A";
  try {
    return new Date(dateString.seconds * 1000).toLocaleString("en-GB", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "Invalid Date";
  }
};

const getStatusPill = (status) => {
  const baseClasses =
    "px-3 py-1 text-sm font-medium rounded-full inline-flex items-center gap-2";
  switch (status?.toLowerCase()) {
    case "submitted":
      return (
        <span className={`${baseClasses} bg-blue-100 text-blue-800`}>
          <FiCheckCircle /> {status}
        </span>
      );
    default:
      return (
        <span className={`${baseClasses} bg-gray-100 text-gray-800`}>
          {status}
        </span>
      );
  }
};

// --- UI SUB-COMPONENTS ---

const ClaimListItem = ({ claim, isSelected, onSelect }) => (
  <div
    onClick={() => onSelect(claim)}
    className={`p-4 cursor-pointer border-l-4 ${
      isSelected
        ? "bg-white border-primary"
        : "bg-transparent border-transparent hover:bg-gray-200"
    } transition-all duration-150`}
  >
    <div className="flex justify-between items-start">
      <h3 className="font-bold text-base text-dark truncate pr-2">
        {claim.id}
      </h3>
      {getStatusPill(claim.status)}
    </div>
    <div className="text-sm text-gray-600 mt-2 space-y-1">
      <div className="flex items-center gap-2">
        <FiUser className="text-gray-500" />
        <span className="truncate">{claim.policyHolder}</span>
      </div>
      <div className="flex items-center gap-2">
        <FiClock className="text-gray-500" />
        <span>{formatDate(claim.createdAt)}</span>
      </div>
    </div>
  </div>
);
ClaimListItem.propTypes = {
  claim: PropTypes.object.isRequired,
  isSelected: PropTypes.bool.isRequired,
  onSelect: PropTypes.func.isRequired,
};

const EvidenceCard = ({ file }) => (
  <div className="bg-white rounded-lg shadow-md p-4 flex flex-col justify-between hover:shadow-xl transition-shadow duration-300">
    <div>
      <div className="flex items-center gap-3">
        <div className="text-3xl">{getFileIcon(file.name)}</div>
        <h4 className="font-semibold text-dark break-all">{file.name}</h4>
      </div>
      <p className="text-sm text-gray-600 mt-3 italic bg-gray-50 p-2 rounded h-24 overflow-y-auto">
        {file.summary || "No summary available."}
      </p>
    </div>
    <a
      href={file.url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-4 w-full flex items-center justify-center gap-2 bg-primary text-white font-bold py-2 px-4 rounded-md hover:bg-primary-dark transition-colors"
    >
      <FiDownload />
      <span>View/Download</span>
    </a>
  </div>
);
EvidenceCard.propTypes = {
  file: PropTypes.object.isRequired,
};

const InfoCard = ({ icon, label, value, colorClass = "text-dark" }) => (
  <div className="bg-gray-50 p-4 rounded-lg flex items-start gap-4">
    <div className="text-2xl text-primary">{icon}</div>
    <div>
      <h4 className="text-sm font-semibold text-gray-500">{label}</h4>
      <p className={`text-lg font-bold break-words ${colorClass}`}>{value}</p>
    </div>
  </div>
);
InfoCard.propTypes = {
  icon: PropTypes.node.isRequired,
  label: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  colorClass: PropTypes.string,
};

const ClaimMetadata = ({ claim }) => {
  const fraudStatusColor =
    claim.redFlags > 0 ? "text-red-500" : "text-green-600";
  const fraudStatusText =
    claim.redFlags > 0 ? `${claim.redFlags} Flag(s)` : "Clear";

  return (
    <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
      <InfoCard
        icon={<FiUser />}
        label="Policy Holder"
        value={claim.policyHolder}
      />
      <InfoCard
        icon={<FiShield />}
        label="Fraud Status"
        value={fraudStatusText}
        colorClass={fraudStatusColor}
      />
      <InfoCard
        icon={<FiTrendingUp />}
        label="Claim Status"
        value={claim.status}
      />
      <InfoCard
        icon={<FiDollarSign />}
        label="Claim Cost"
        value={formatCurrency(750)}
      />
    </section>
  );
};
ClaimMetadata.propTypes = {
  claim: PropTypes.object.isRequired,
};

const ExtractedFieldsCard = ({ claim }) => {
  const extractedFields = useMemo(() => {
    console.log("[ExtractedFieldsCard] Recalculating extracted fields.");
    const knownKeys = new Set([
      "id",
      "policyId",
      "policyHolder",
      "status",
      "createdAt",
      "summary",
      "fraudDetected",
      "redFlags",
      "fraudInfo",
      "estimatedCost",
    ]);
    return Object.entries(claim)
      .filter(([key]) => !knownKeys.has(key))
      .map(([key, value]) => ({
        key: key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
        value,
      }));
  }, [claim]);

  if (extractedFields.length === 0) {
    return null;
  }

  return (
    <section>
      <h3 className="text-xl font-bold text-primary mb-3 flex items-center gap-2">
        <FiCpu /> Extracted Data
      </h3>
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
          {extractedFields.map(({ key, value }) => (
            <div key={key}>
              <h4 className="text-sm font-semibold text-gray-500">{key}</h4>
              <p className="text-base text-dark break-words">
                {value || "N/A"}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
ExtractedFieldsCard.propTypes = {
  claim: PropTypes.object.isRequired,
};

const ClaimDetails = ({ claim, evidence, isLoadingEvidence }) => {
  if (!claim) {
    return (
      <div className="flex items-center justify-center h-full bg-white">
        <div className="text-center">
          <FiInbox className="mx-auto text-6xl text-gray-300" />
          <p className="mt-4 text-xl text-gray-500">
            Select a claim to view its details
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white h-full overflow-y-auto">
      <header className="p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-dark">{claim.id}</h2>
            <p className="text-lg text-gray-500 flex items-center gap-2">
              <FiTag /> Policy No: {claim.policyId}
            </p>
          </div>
          <button className="bg-red-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-red-700 transition-all transform hover:-translate-y-0.5">
            Detect Fraud
          </button>
        </div>
      </header>

      <main className="p-6 space-y-8">
        <ClaimMetadata claim={claim} />

        <ExtractedFieldsCard claim={claim} />

        {claim.redFlags > 0 && (
          <section>
            <h3 className="text-xl font-bold text-red-600 mb-3 flex items-center gap-2">
              <FiAlertTriangle /> Fraud Indicators
            </h3>
            <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
              <ul className="list-disc list-inside text-red-700 space-y-1">
                {claim.fraudInfo.map((flag, index) => (
                  <li key={index}>
                    <FiFlag className="inline mr-2" />
                    {flag}
                  </li>
                ))}
              </ul>
            </div>
          </section>
        )}

        <section>
          <h3 className="text-xl font-bold text-primary mb-4">Evidence Deck</h3>
          {isLoadingEvidence ? (
            <p className="text-gray-500">Loading evidence...</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {evidence.map((file) => (
                <EvidenceCard key={file.url} file={file} />
              ))}
              {evidence.length === 0 && (
                <p className="text-gray-500">
                  No evidence has been uploaded for this claim.
                </p>
              )}
            </div>
          )}
        </section>
      </main>
    </div>
  );
};
ClaimDetails.propTypes = {
  claim: PropTypes.object,
  evidence: PropTypes.array.isRequired,
  isLoadingEvidence: PropTypes.bool.isRequired,
};

// --- MAIN DASHBOARD COMPONENT ---

const Dashboard = () => {
  const [claims, setClaims] = useState([]);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [evidence, setEvidence] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingEvidence, setIsLoadingEvidence] = useState(false);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSelectClaim = (claim) => {
    console.log(`[Dashboard] Claim selected: ${claim.id}`);
    setSelectedClaim(claim);

    const fetchEvidence = async (claimId) => {
      setIsLoadingEvidence(true);
      setEvidence([]);
      try {
        console.log(`[Dashboard] Fetching evidence for claim: ${claimId}`);
        const response = await fetch(`${API_URL}/policies/${claimId}/evidence`);
        if (!response.ok)
          throw new Error(`HTTP error! status: ${response.status}`);
        const evidenceData = await response.json();
        console.log(`[Dashboard] ✅ Evidence fetched:`, evidenceData);
        setEvidence(evidenceData);
      } catch (e) {
        console.error(`[Dashboard] 🔴 Failed to fetch evidence:`, e);
      } finally {
        setIsLoadingEvidence(false);
      }
    };

    if (claim?.id) {
      fetchEvidence(claim.id);
    }
  };

  useEffect(() => {
    console.log("[Dashboard] Component mounted. Fetching claims...");
    const fetchClaims = async () => {
      try {
        setError(null);
        setIsLoading(true);
        const response = await fetch(`${API_URL}/policies`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log("[Dashboard] ✅ Claims fetched successfully:", data);
        setClaims(data);
        if (data.length > 0) {
          handleSelectClaim(data[0]);
        }
      } catch (e) {
        console.error("[Dashboard] 🔴 Failed to fetch claims:", e);
        setError("Failed to load claims data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchClaims();
  }, []);

  const filteredClaims = useMemo(
    () =>
      claims.filter(
        (claim) =>
          claim.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          claim.policyId.toLowerCase().includes(searchTerm.toLowerCase()) ||
          claim.policyHolder.toLowerCase().includes(searchTerm.toLowerCase()),
      ),
    [claims, searchTerm],
  );

  return (
    <div className="flex h-screen bg-gray-100 font-sans">
      <aside className="w-full md:w-4/12 lg:w-3/12 flex flex-col bg-gray-100 border-r border-gray-200">
        <header className="p-4 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-primary">ClaimAI Dashboard</h1>
          <div className="relative mt-4">
            <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by ID, Policy, Name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </header>
        <nav className="flex-1 overflow-y-auto">
          {isLoading && (
            <p className="p-4 text-center text-gray-500">Loading claims...</p>
          )}
          {error && <p className="p-4 text-center text-red-500">{error}</p>}
          {!isLoading &&
            !error &&
            (filteredClaims.length > 0 ? (
              filteredClaims.map((claim) => (
                <ClaimListItem
                  key={claim.id}
                  claim={claim}
                  isSelected={selectedClaim?.id === claim.id}
                  onSelect={handleSelectClaim}
                />
              ))
            ) : (
              <p className="p-4 text-center text-gray-500">No claims found.</p>
            ))}
        </nav>
      </aside>

      <main className="w-full md:w-8/12 lg:w-9/12">
        <ClaimDetails
          claim={selectedClaim}
          evidence={evidence}
          isLoadingEvidence={isLoadingEvidence}
        />
      </main>
    </div>
  );
};

export default Dashboard;
