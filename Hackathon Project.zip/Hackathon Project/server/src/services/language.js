/**
 * @fileoverview This service interfaces with the Google Cloud Vertex AI API (Gemini).
 * It has been refactored for better logging, robust error handling, and clarity.
 *
 * The main function, `summarizeText`, takes a block of text and uses a generative
 * model to produce a concise, single-sentence summary.
 */
import { VertexAI } from "@google-cloud/vertexai";
import { PROJECT_ID } from "../util/env.js";

/* ------------------------------------------------------------------ */
/*  Initialize Vertex AI Client and Generative Model                  */
/* ------------------------------------------------------------------ */
console.log("[LanguageAI] Initializing Vertex AI client...");

const vertex_ai = new VertexAI({
  project: PROJECT_ID,
  location: "us-central1", // A supported Vertex AI location
});

// Use a specific Gemini model. This can be swapped for others like "gemini-1.5-flash".
const model = "gemini-2.5-flash";
const generativeModel = vertex_ai.getGenerativeModel({ model });

console.log(`[LanguageAI] ✅ Client initialized. Using model: ${model}`);

/* ------------------------------------------------------------------ */
/*  Helper: Call Gemini to Generate a Text Summary                    */
/* ------------------------------------------------------------------ */
/**
 * Generates a concise, one-sentence summary for a given block of text.
 *
 * @param {string} text The text to be summarized.
 * @returns {Promise<string>} A promise that resolves to the AI-generated summary,
 *   a default message if the text is too short, or an error message on failure.
 */
export async function summarizeText(text) {
  console.log(
    `[LanguageAI] summarizeText called with text of length: ${text?.length || 0}.`,
  );

  if (!text || text.trim().length < 50) {
    console.log(
      "[LanguageAI] ⚠️ Text is too short to summarize. Returning default message.",
    );
    return "The document does not contain enough text to generate a summary.";
  }

  const prompt = `Generate a single, concise sentence that describes what this document is about.

Document Text:
---
${text}
---
`;

  try {
    console.log("[LanguageAI] Calling Vertex AI generateContent API...");
    const resp = await generativeModel.generateContent(prompt);
    console.log("[LanguageAI] ✅ API call successful. Analyzing response.");

    // Safely access the response text using optional chaining
    const responseText =
      resp.response?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (responseText) {
      console.log(`[LanguageAI] Generated summary: "${responseText}"`);
      return responseText;
    } else {
      console.warn(
        "[LanguageAI] ⚠️ AI response was valid but contained no text content.",
      );
      return "AI summary could not be generated from the response.";
    }
  } catch (err) {
    console.error(
      "🔴 [LanguageAI] FATAL: An error occurred during the Vertex AI API call. Full error object:",
      err,
    );
    // Return a user-friendly error message
    return "An error occurred while generating the AI summary.";
  }
}
