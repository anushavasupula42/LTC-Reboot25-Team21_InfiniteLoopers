import "dotenv/config";
import express from "express";
import cors from "cors";

import uploadRoute from "./routes/upload.js";
import policiesRoute from "./routes/policies.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/upload", uploadRoute);
app.use("/api/policies", policiesRoute);

app.listen(process.env.PORT || 4000, () =>
  console.log(`API listening on :${process.env.PORT || 4000}`)
);
