/**
 * This file contains the route handler for file uploads.
 * It has been refactored to improve modularity, error handling, and logging.
 *
 * Key Improvements:
 * - A dedicated `processSingleFile` function now encapsulates the logic for
 *   handling each uploaded file, making the main route handler cleaner.
 * - MIME type validation logic now directly uses constants imported from
 *   `util/fileTypes.js` for clarity and directness.
 * - Logging has been enhanced with consistent prefixes to clearly trace the
 *   flow of a request through GCS upload, AI analysis, and Firestore creation.
 * - Error handling now provides more specific context when a single file fails.
 */
import { Router } from "express";
import multer from "multer";
import { uploadFile } from "../services/storage.js";
import { extractFields } from "../services/docAI.js";
import { summarizeImage } from "../services/vision.js";
import { summarizeText } from "../services/language.js";
import { createClaim } from "../services/firestore.js";
// Import constants directly for inline validation
import { DOCUMENT_MIMES, IMAGE_PREFIX } from "../util/fileTypes.js";

const router = Router();

/* ------------------------------------------------------------------ */
/*  Multer Configuration for File Uploads                             */
/* ------------------------------------------------------------------ */
console.log("[MULTER] Configuring file upload middleware...");
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024, files: 10 }, // 15MB limit, max 10 files
  fileFilter: (_, file, cb) => {
    console.log(
      `[MULTER] Filtering file: ${file.originalname} (${file.mimetype})`,
    );
    const isAllowed =
      DOCUMENT_MIMES.includes(file.mimetype) ||
      file.mimetype.startsWith(IMAGE_PREFIX);

    if (isAllowed) {
      console.log(`[MULTER] ✅ Allowed: ${file.originalname}`);
      cb(null, true);
    } else {
      console.error(
        `[MULTER] 🔴 Rejected: ${file.originalname}. Invalid MIME type.`,
      );
      cb(
        new Error(
          `File type ${file.mimetype} is not allowed. Please upload supported documents or images.`,
        ),
      );
    }
  },
});
console.log("[MULTER] Configuration complete.");

/* ------------------------------------------------------------------ */
/*  Helper Function: Process a Single Uploaded File                   */
/* ------------------------------------------------------------------ */
/**
 * Handles the processing of a single file: uploads to GCS and performs AI analysis.
 * @param {object} file - The file object from multer.
 * @param {number} index - The index of the file in the request.
 * @param {number} totalFiles - The total number of files being processed.
 * @returns {Promise<object>} A promise that resolves to the processed file data.
 */
async function processSingleFile(file, index, totalFiles) {
  const fileLogPrefix = `[PROCESSOR] [File ${index + 1}/${totalFiles}] (${
    file.originalname
  })`;
  console.log(`${fileLogPrefix} - Starting processing...`);

  try {
    // 1. Upload to Google Cloud Storage
    console.log(`${fileLogPrefix} - Uploading to GCS...`);
    const gcsUrl = await uploadFile(file);
    console.log(`${fileLogPrefix} - ✅ GCS Upload successful. URL: ${gcsUrl}`);

    let fields = {};
    let summary = "";

    // 2. Process with AI based on MIME type
    if (DOCUMENT_MIMES.includes(file.mimetype)) {
      console.log(
        `${fileLogPrefix} - Processing as document with Document AI...`,
      );
      const { fields: extractedFields, text } = await extractFields(
        file.buffer,
        file.mimetype,
      );
      fields = extractedFields;
      console.log(
        `${fileLogPrefix} - ✅ Document AI extracted ${
          Object.keys(fields).length
        } fields.`,
      );

      if (text && text.trim().length > 0) {
        console.log(
          `${fileLogPrefix} - Summarizing extracted text with Language AI...`,
        );
        summary = await summarizeText(text);
        console.log(`${fileLogPrefix} - ✅ Language AI summary generated.`);
      } else {
        console.log(`${fileLogPrefix} - ⚠️ No text found to summarize.`);
        summary = "No text content found in document to summarize.";
      }
    } else if (file.mimetype.startsWith(IMAGE_PREFIX)) {
      console.log(`${fileLogPrefix} - Processing as image with Vision AI...`);
      summary = await summarizeImage(file.buffer, file.mimetype);
      console.log(`${fileLogPrefix} - ✅ Vision AI summary generated.`);
    }

    console.log(`${fileLogPrefix} - ✅ Successfully processed.`);
    return { name: file.originalname, url: gcsUrl, fields, summary };
  } catch (error) {
    console.error(`${fileLogPrefix} - 🔴 Error during processing:`, error);
    // Re-throw to ensure Promise.all fails fast and the client gets an error.
    throw new Error(
      `Failed to process file ${file.originalname}: ${error.message}`,
    );
  }
}

/* ------------------------------------------------------------------ */
/*  API Endpoint: Process uploads and create a single new claim       */
/* ------------------------------------------------------------------ */
router.post("/", upload.array("files", 10), async (req, res) => {
  console.log("\n--- [UPLOAD] New Claim Submission Received ---");
  console.log("[UPLOAD] Handling POST request to /api/upload");

  const { policyId } = req.query;
  console.log(`[UPLOAD] Associated Policy ID: '${policyId}'`);

  if (!policyId) {
    console.error("[UPLOAD] 🔴 Error: No policyId provided. Aborting.");
    return res.status(400).send("A `policyId` query parameter is required.");
  }

  if (!req.files || req.files.length === 0) {
    console.error("[UPLOAD] 🔴 Error: No files were uploaded. Aborting.");
    return res
      .status(400)
      .send("At least one file must be uploaded to create a claim.");
  }

  console.log(`[UPLOAD] Found ${req.files.length} files to process.`);

  try {
    // Process all files in parallel
    const processingPromises = req.files.map((file, index) =>
      processSingleFile(file, index, req.files.length),
    );
    const uploadedFiles = await Promise.all(processingPromises);
    console.log("[UPLOAD] ✅ All files have been processed successfully.");

    // Create a single claim in Firestore with the aggregated data
    console.log(
      `[FIRESTORE] Creating a new claim in Firestore for policy '${policyId}'...`,
    );
    const newClaim = await createClaim({ policyId, uploadedFiles });
    console.log(
      `[FIRESTORE] ✅ Successfully created claim ${newClaim.id} in Firestore.`,
    );

    // Respond to the client with the new claim data
    console.log(
      `[UPLOAD] Sending successful response (201) to client with claim ID: ${newClaim.id}.`,
    );
    console.log("--- [UPLOAD] Claim Submission Finished ---\n");
    res.status(201).json(newClaim);
  } catch (err) {
    console.error("--- [UPLOAD] 🔴 Claim Submission Failed ---");
    console.error(
      "[UPLOAD] An error occurred during the claim creation process:",
      err,
    );

    if (err.message.includes("not found")) {
      // Specifically handle 'Policy not found' errors from createClaim
      res.status(404).send(err.message);
    } else {
      res
        .status(500)
        .send(
          `An error occurred during the claim creation process: ${err.message}`,
        );
    }
  }
});

export default router;
