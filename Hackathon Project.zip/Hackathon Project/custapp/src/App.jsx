import { useState } from "react";
import EvidenceForm from "./EvidenceForm";
import PropTypes from "prop-types";

// Get API base URL from environment variables, with a fallback for development.
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

// Configuration for claim categories, remains client-side for UI rendering.
const claimConfig = {
  gold: {
    categories: [
      { id: "accident", label: "Accident / Collision" },
      { id: "theft", label: "Theft / attempted theft" },
      { id: "damage", label: "Damage (fire, vandalism, weather)" },
      { id: "courtesy_car", label: "Courtesy-car / alt. travel costs" },
      { id: "misfuelling", label: "Misfuelling (UK)" },
      { id: "keys_locks", label: "Keys / Locks replacement" },
      { id: "child_seat", label: "Child car-seat replacement" },
      { id: "audio_satnav", label: "Audio / sat-nav equipment" },
      { id: "third_party", label: "Third-party injury / property" },
    ],
  },
  silver: {
    categories: [
      { id: "accident", label: "Accident / Collision" },
      { id: "theft", label: "Theft / attempted theft" },
      { id: "damage", label: "Damage (fire, vandalism, weather)" },
      { id: "courtesy_car", label: "Courtesy-car / alt. travel costs" },
      { id: "audio_satnav", label: "Audio / sat-nav equipment" },
      { id: "third_party", label: "Third-party injury / property" },
    ],
  },
};

// A new component for the progress bar UI
const UploadProgress = ({ progress }) => (
  <div className="w-full">
    <div className="w-full bg-gray-200 rounded-full h-4">
      <div
        className="bg-primary h-4 rounded-full transition-all duration-300 ease-in-out"
        style={{ width: `${progress}%` }}
      ></div>
    </div>
    <p className="text-center text-sm font-medium mt-2 text-dark">
      Uploading... {Math.round(progress)}%
    </p>
  </div>
);

UploadProgress.propTypes = {
  progress: PropTypes.number.isRequired,
};

// Main application component that drives the claim wizard.
export default function App() {
  const [policyNumber, setPolicyNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [policyData, setPolicyData] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState("lookup"); // lookup, otp, wizard, evidence, review, submitting, submitted
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [claimData, setClaimData] = useState(null); // Will hold FormData for submission
  const [finalClaim, setFinalClaim] = useState(null); // To store the successful claim response
  const [uploadProgress, setUploadProgress] = useState(0);

  // --- API and Event Handlers ---

  // 1. Handles the initial policy lookup by calling the backend API.
  const handlePolicySubmit = async (e) => {
    e.preventDefault();
    console.log("[App] Step 1: handlePolicySubmit triggered.");
    setIsLoading(true);
    setErrorMessage("");
    setPolicyData(null);

    try {
      const policyId = policyNumber.toUpperCase().trim();
      console.log(
        `[App] Fetching policy from: ${API_URL}/policies/${policyId}`,
      );
      const response = await fetch(`${API_URL}/policies/${policyId}`);
      const data = await response.json();

      if (!response.ok) {
        console.error("[App] Policy not found or API error:", data.message);
        throw new Error(data.message || "Policy not found.");
      }

      console.log("[App] ✅ Policy found:", data);
      setPolicyData(data);
      setStep("otp");
    } catch (err) {
      console.error("[App] 🔴 Error during policy lookup:", err);
      setErrorMessage(
        err.message ||
          "Failed to find policy. Please check the number and try again.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Handles OTP verification (client-side).
  const handleOtpSubmit = (e) => {
    e.preventDefault();
    console.log("[App] Step 2: handleOtpSubmit triggered.");
    if (policyData && otp === policyData.otp) {
      console.log("[App] ✅ OTP correct.");
      setStep("wizard");
      setErrorMessage("");
    } else {
      console.error("[App] 🔴 Invalid OTP entered.");
      setErrorMessage("Invalid OTP. Please try again.");
    }
  };

  // 3. Sets the selected claim category and moves to the evidence step.
  const handleCategorySelect = (category) => {
    console.log(`[App] Step 3: Category selected: ${category.label}`);
    setSelectedCategory({
      ...category,
      policyNumber: policyNumber.toUpperCase().trim(),
    });
    setStep("evidence");
  };

  // 4. Stores the collected evidence and moves to the review step.
  const handleEvidenceSubmit = (formData) => {
    console.log(
      "[App] Step 4: Evidence form submitted. Moving to review step.",
    );
    // Log FormData contents for debugging
    for (const [key, value] of formData.entries()) {
      console.log(`[App]   - FormData content: ${key}:`, value.name || value);
    }
    setClaimData(formData);
    setStep("review");
  };

  // 5. Handles the final submission of the claim to the backend with progress.
  const handleFinalSubmit = async () => {
    console.log("[App] Step 5: Final submission triggered.");
    if (!claimData) {
      setErrorMessage("No claim data available to submit.");
      return;
    }

    setIsLoading(true);
    setErrorMessage("");
    setStep("submitting"); // Move to a dedicated submitting step to show progress
    setUploadProgress(0);

    // Using XMLHttpRequest to get upload progress events
    const xhr = new XMLHttpRequest();

    // Listener for upload progress
    xhr.upload.addEventListener("progress", (event) => {
      if (event.lengthComputable) {
        const percentage = (event.loaded / event.total) * 100;
        console.log(`[App] Upload progress: ${percentage.toFixed(2)}%`);
        setUploadProgress(percentage);
      }
    });

    // Listener for when the request is complete
    xhr.addEventListener("load", () => {
      console.log(
        `[App] Upload complete. Server responded with status: ${xhr.status}`,
      );
      setIsLoading(false);
      if (xhr.status >= 200 && xhr.status < 300) {
        const responseData = JSON.parse(xhr.responseText);
        console.log("[App] ✅ Claim created successfully:", responseData);
        setFinalClaim(responseData);
        setStep("submitted");
      } else {
        const errorResponse = JSON.parse(xhr.responseText || "{}");
        const errorMessage =
          errorResponse.message || `Server error: ${xhr.statusText}`;
        console.error(`[App] 🔴 Server error after upload:`, errorMessage);
        setErrorMessage(errorMessage);
        setStep("review"); // Go back to review step on error
      }
    });

    // Listener for network errors
    xhr.addEventListener("error", () => {
      console.error("[App] 🔴 A network error occurred during the upload.");
      setErrorMessage(
        "A network error occurred during upload. Please try again.",
      );
      setIsLoading(false);
      setStep("review");
    });

    const policyId = policyNumber.toUpperCase().trim();
    const url = `${API_URL}/upload?policyId=${policyId}`;
    console.log(`[App] Opening XHR POST request to: ${url}`);
    xhr.open("POST", url, true);

    // The browser will set the Content-Type header with the correct boundary
    // when sending FormData.
    xhr.send(claimData);
  };

  // --- UI Rendering ---

  const renderContent = () => {
    switch (step) {
      case "lookup":
        return (
          <form onSubmit={handlePolicySubmit} className="space-y-6">
            <h1 className="text-3xl font-bold text-center text-dark">
              Customer Claim Portal
            </h1>
            <div>
              <label
                htmlFor="policyNumber"
                className="block text-sm font-medium text-gray-700"
              >
                Please enter your Policy Number
              </label>
              <input
                type="text"
                id="policyNumber"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                value={policyNumber}
                onChange={(e) => setPolicyNumber(e.target.value)}
                placeholder="e.g., POL001"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
            >
              {isLoading ? "Searching..." : "Find Policy"}
            </button>
            {errorMessage && (
              <p className="mt-2 text-sm text-red-600 text-center">
                {errorMessage}
              </p>
            )}
          </form>
        );

      case "otp":
        return (
          <form onSubmit={handleOtpSubmit} className="space-y-6">
            <h2 className="text-2xl font-semibold text-center text-dark">
              Welcome, {policyData.policyHolder}
            </h2>
            <p className="text-center text-gray-600">
              For security, please enter the OTP sent to your registered mobile.
            </p>
            <div>
              <label
                htmlFor="otp"
                className="block text-sm font-medium text-gray-700"
              >
                OTP
              </label>
              <input
                type="text"
                id="otp"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Confirm & Proceed
            </button>
            {errorMessage && (
              <p className="mt-2 text-sm text-red-600 text-center">
                {errorMessage}
              </p>
            )}
          </form>
        );

      case "wizard": {
        const userTier = policyData.policyType;
        const availableCategories = claimConfig[userTier]?.categories || [];
        return (
          <div>
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-dark">
                Welcome, {policyData.policyHolder}
              </h2>
              <p className="mb-4 text-gray-600">
                Your Policy Tier:{" "}
                <span className="font-bold capitalize text-primary">
                  {userTier}
                </span>
              </p>
            </div>
            <div className="border-t pt-4 mt-4">
              <h3 className="text-xl font-medium mb-4 text-center text-dark">
                Please select a claim category:
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availableCategories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => handleCategorySelect(category)}
                    className="p-4 border rounded-lg text-left text-dark hover:bg-gray-50 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all duration-200"
                  >
                    <p className="font-semibold">{category.label}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );
      }

      case "evidence":
        return (
          <EvidenceForm
            category={selectedCategory}
            onBack={() => setStep("wizard")}
            onSubmit={handleEvidenceSubmit}
          />
        );

      case "review": {
        const entries = claimData ? Array.from(claimData.entries()) : [];
        return (
          <div>
            <h2 className="text-2xl font-bold text-center mb-4 text-dark">
              Review Your Claim
            </h2>
            <div className="bg-gray-50 p-4 rounded-lg space-y-2 max-h-60 overflow-y-auto">
              {entries.map(([key, value]) => (
                <div key={key} className="text-sm">
                  <span className="font-semibold text-dark capitalize">
                    {key.replace("[]", "")}:{" "}
                  </span>
                  <span className="text-gray-700">{value.name}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-4 text-center">
              Please confirm the information you have provided is accurate to
              the best of your knowledge before submitting.
            </p>
            {errorMessage && (
              <p className="mt-2 text-sm text-red-600 text-center">
                {errorMessage}
              </p>
            )}
            <div className="mt-6 flex justify-between">
              <button
                onClick={() => setStep("evidence")}
                className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Edit
              </button>
              <button
                onClick={handleFinalSubmit}
                disabled={isLoading}
                className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50"
              >
                {isLoading ? "Submitting..." : "Accept & Submit"}
              </button>
            </div>
          </div>
        );
      }

      case "submitting":
        return (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-dark mb-6">
              Submitting Your Claim
            </h2>
            <p className="text-gray-600 mb-4">
              Please wait while we upload and process your evidence. Do not
              close this window.
            </p>
            <UploadProgress progress={uploadProgress} />
          </div>
        );

      case "submitted":
        return (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-primary">
              Claim Submitted Successfully!
            </h2>
            <p className="mt-4 text-gray-800">
              This is your claim ID, store it for future reference:
            </p>
            <p className="mt-2 text-2xl font-mono bg-gray-100 text-dark inline-block px-4 py-2 rounded-md">
              {finalClaim?.id || "Generating..."}
            </p>
          </div>
        );

      default:
        return <p>Something went wrong. Please refresh the page.</p>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-4">
      <div className="max-w-2xl w-full bg-white p-8 border border-gray-200 rounded-xl shadow-lg">
        {renderContent()}
      </div>
    </div>
  );
}
