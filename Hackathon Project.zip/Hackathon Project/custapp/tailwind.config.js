import forms from "@tailwindcss/forms";

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#00864F",
        "primary-dark": "#006B3F", // A darker shade for hover/focus states
        dark: "#231F20",
      },
    },
  },
  plugins: [forms],
};
