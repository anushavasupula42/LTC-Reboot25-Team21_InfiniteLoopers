import Dashboard from "./pages/Dashboard";
import "./index.css";

function App() {
  return <Dashboard />;
}

export default App;
