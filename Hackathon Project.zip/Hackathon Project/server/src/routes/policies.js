/**
 * This file has been refactored to separate policy and claim data handling.
 * - The main GET `/` route now serves the list of all claims from the `claims`
 *   collection, which is what the agent dashboard expects.
 * - The GET `/:id` route remains, serving a single policy document from the
 *   `policies` collection. This is used by the customer app to validate a
 *   policy ID before initiating a claim.
 * - All claim creation and deletion logic has been removed, as it is now
 *   handled by the upload and dedicated claim services.
 */
import { Router } from "express";
// 'db' is no longer directly exported, so we import only the collections.
import { policiesCol, claimsCol } from "../services/firestore.js";

const router = Router();

/* ------------------------------------------------------------------ */
/*  DATABASE SEEDING (for policies)                                   */
/* ------------------------------------------------------------------ */
// This function runs on startup to ensure a set of demo policies
// exist in the database for the customer app to use.

const initialPolicies = [
  {
    id: "POL001",
    policyHolder: "John Doe",
    phoneNumber: "+447123456789",
    policyType: "gold",
    otp: "7801",
    policyAt: "2023-01-15",
  },
  {
    id: "POL002",
    policyHolder: "Jane Smith",
    phoneNumber: "+447987654321",
    policyType: "silver",
    otp: "7802",
    policyAt: "2022-11-20",
  },
  {
    id: "POL003",
    policyHolder: "Peter Jones",
    phoneNumber: "+447111222333",
    policyType: "gold",
    otp: "7803",
    policyAt: "2023-05-10",
  },
  {
    id: "POL004",
    policyHolder: "Mary Williams",
    phoneNumber: "+447444555666",
    policyType: "silver",
    otp: "7804",
    policyAt: "2021-08-01",
  },
];

async function seedPolicies() {
  try {
    const snapshot = await policiesCol.limit(1).get();
    if (snapshot.empty) {
      console.log("🌱 Policies collection is empty. Seeding database...");
      // FIX: Get the Firestore instance from the collection reference
      // to create a batch, since 'db' is no longer exported.
      const batch = policiesCol.firestore.batch();
      initialPolicies.forEach((policy) => {
        const docRef = policiesCol.doc(policy.id);
        batch.set(docRef, policy);
      });
      await batch.commit();
      console.log("✅ Database seeded successfully with initial policies.");
    }
  } catch (error) {
    console.error("❌ Error seeding policies:", error);
  }
}

// Run the seeder on startup
seedPolicies();

/* ------------------------------------------------------------------ */
/*  API ROUTES                                                        */
/* ------------------------------------------------------------------ */

/**
 * GET /api/policies
 * Lists all documents from the `claims` collection.
 * This is used by the agent dashboard to display all submitted claims.
 */
router.get("/", async (_, res) => {
  try {
    const snapshot = await claimsCol.orderBy("createdAt", "desc").get();
    res.json(snapshot.docs.map((d) => d.data()));
  } catch (error) {
    console.error("Error listing claims:", error);
    res.status(500).send("Internal Server Error");
  }
});

/**
 * GET /api/policies/:id
 * Fetches a single policy document from the `policies` collection.
 * This is used by the customer app to verify a policy ID exists before
 * allowing a user to proceed with a claim submission.
 */
router.get("/:id", async (req, res) => {
  try {
    const doc = await policiesCol.doc(req.params.id.toUpperCase()).get();
    if (doc.exists) {
      res.json(doc.data());
    } else {
      res.status(404).json({ message: "Policy not found" });
    }
  } catch (error) {
    console.error(`Error fetching policy ${req.params.id}:`, error);
    res.status(500).send("Internal Server Error");
  }
});

/**
 * GET /api/policies/:id/evidence
 * Fetches all documents from the 'evidence' sub-collection for a specific claim.
 * The ':id' here refers to the Claim ID (e.g., "CLM123456").
 * This is used by the agent dashboard to load evidence files for a selected claim.
 */
router.get("/:id/evidence", async (req, res) => {
  const { id: claimId } = req.params;
  try {
    const evidenceColRef = claimsCol.doc(claimId).collection("evidence");
    const snapshot = await evidenceColRef.orderBy("uploadedAt", "asc").get();

    if (snapshot.empty) {
      // No error, just return an empty array if no evidence exists.
      return res.json([]);
    }

    const evidence = snapshot.docs.map((doc) => doc.data());
    res.json(evidence);
  } catch (error) {
    console.error(`[API] Error fetching evidence for claim ${claimId}:`, error);
    res.status(500).send("Internal Server Error");
  }
});

export default router;
