import { useState } from "react";
import PropTypes from "prop-types";

// This configuration defines the evidence required for each claim category.
// It's designed to be easily extensible for new claim types.
const evidenceConfig = {
  accident: [
    {
      id: "statement_doc",
      type: "file",
      label: "Accident Statement (include date, time, location, etc.)",
      mandatory: true,
    },
    {
      id: "scene_photos",
      type: "file",
      label: "Photos / Videos of Scene & Vehicle Damage",
      mandatory: true,
    },
    {
      id: "licence_mot",
      type: "file",
      label: "Driver’s Licence & MOT Certificate",
      mandatory: true,
    },
    {
      id: "repair_estimate",
      type: "file",
      label: "Repair Estimate or Invoice",
      mandatory: true,
    },
    {
      id: "police_report",
      type: "file",
      label: "Police Report (if applicable)",
      mandatory: false,
    },
    {
      id: "dashcam",
      type: "file",
      label: "Dash-cam Footage",
      mandatory: false,
    },
    {
      id: "witness_info_doc",
      type: "file",
      label: "Witness Statements or Contact Info",
      mandatory: false,
    },
  ],
  theft: [
    {
      id: "police_report_theft",
      type: "file",
      label: "Police Report with Crime Reference #",
      mandatory: true,
    },
    {
      id: "narrative_doc",
      type: "file",
      label: "Incident Statement (when/where last seen)",
      mandatory: true,
    },
    {
      id: "v5c_docs",
      type: "file",
      label: "Vehicle V5C or Finance Docs",
      mandatory: true,
    },
  ],
  damage: [
    {
      id: "damage_photos",
      type: "file",
      label: "Photos of Damage",
      mandatory: true,
    },
    {
      id: "repair_estimate_damage",
      type: "file",
      label: "Repair Estimate",
      mandatory: true,
    },
  ],
  // Other categories simplified for brevity but follow the same structure
  misfuelling: [
    {
      id: "fuel_receipt",
      type: "file",
      label: "Fuel Purchase Receipt",
      mandatory: true,
    },
    {
      id: "garage_report",
      type: "file",
      label: "Garage Drain/Flush Report",
      mandatory: true,
    },
  ],
  keys_locks: [
    {
      id: "replacement_invoice",
      type: "file",
      label: "Invoice for Replacement Keys / Locksmith",
      mandatory: true,
    },
  ],
  child_seat: [
    {
      id: "accident_ref_photos",
      type: "file",
      label: "Photos of Accident or Damage",
      mandatory: true,
    },
    {
      id: "purchase_receipt",
      type: "file",
      label: "Purchase Receipt for Child Seat",
      mandatory: true,
    },
  ],
  courtesy_car: [
    {
      id: "car_unavailable_proof",
      type: "file",
      label: "Repairer Confirmation (Courtesy Car Unavailable)",
      mandatory: true,
    },
    {
      id: "transport_receipts",
      type: "file",
      label: "Receipts for Public Transport / Hire Costs",
      mandatory: true,
    },
  ],
  audio_satnav: [
    {
      id: "audio_receipts",
      type: "file",
      label: "Receipts for Audio/Sat-Nav Equipment",
      mandatory: true,
    },
    {
      id: "audio_photos",
      type: "file",
      label: "Photos of the Equipment",
      mandatory: true,
    },
  ],
  third_party: [
    {
      id: "incident_statement",
      type: "file",
      label: "Statement of Incident (include third-party details)",
      mandatory: true,
    },
  ],
};

// Reusable Input Field Component for rendering file inputs.
const FormField = ({ field, onChange }) => {
  const commonClasses =
    "mt-1 block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none";
  const label = `${field.label}${field.mandatory ? " *" : ""}`;

  return (
    <div>
      <label
        htmlFor={field.id}
        className="block text-sm font-medium text-gray-700"
      >
        {label}
      </label>
      <input
        type="file"
        id={field.id}
        name={field.id} // Name is used in handleChange to identify the field
        onChange={onChange}
        className={`${commonClasses} file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-gray-200 file:text-primary-dark hover:file:bg-gray-300`}
        multiple
      />
    </div>
  );
};

FormField.propTypes = {
  field: PropTypes.shape({
    id: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
    mandatory: PropTypes.bool,
  }).isRequired,
  onChange: PropTypes.func.isRequired,
};

// Main Evidence Form Component
export default function EvidenceForm({ category, onBack, onSubmit }) {
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const fields = evidenceConfig[category.id] || [];
  console.log(
    `[EvidenceForm] Rendering for category: ${category.label}. Found ${fields.length} fields.`,
  );

  const validate = () => {
    console.log("[EvidenceForm] Starting validation...");
    const newErrors = {};
    fields.forEach((field) => {
      if (
        field.mandatory &&
        (!formData[field.id] || formData[field.id].length === 0)
      ) {
        newErrors[field.id] = `${field.label} is required.`;
        console.log(
          `[EvidenceForm]   - 🔴 Validation FAILED for mandatory field: ${field.id}`,
        );
      }
    });
    setErrors(newErrors);
    const isValid = Object.keys(newErrors).length === 0;
    console.log(
      `[EvidenceForm] Validation complete. Is form valid? ${isValid}`,
    );
    return isValid;
  };

  const handleChange = (e) => {
    const { name, files } = e.target;
    console.log(
      `[EvidenceForm] handleChange for field '${name}'. ${files.length} file(s) selected.`,
    );
    setFormData((prev) => ({
      ...prev,
      [name]: files, // Store the FileList object from the input
    }));

    // Clear the error for the field being edited
    if (errors[name]) {
      console.log(`[EvidenceForm] Clearing error for field '${name}'.`);
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("[EvidenceForm] handleSubmit triggered.");
    if (validate()) {
      console.log("[EvidenceForm] Validation passed. Preparing payload.");
      const payload = new FormData();

      // The backend `upload.array('files', 10)` endpoint expects all files
      // under a single field name: "files".
      Object.entries(formData).forEach(([key, fileList]) => {
        if (fileList instanceof FileList) {
          for (let i = 0; i < fileList.length; i++) {
            console.log(
              `[EvidenceForm]   - Appending file '${fileList[i].name}' from input '${key}' to payload with key 'files'`,
            );
            payload.append("files", fileList[i]);
          }
        }
      });

      // Append other data the backend might need for context, like category.
      // This is not strictly needed by the upload endpoint but is good practice.
      payload.append("policyCategory", category.id);
      console.log(`[EvidenceForm] Appended policyCategory: ${category.id}`);

      console.log("[EvidenceForm] Payload prepared. Calling onSubmit.");
      onSubmit(payload);
    } else {
      console.log("[EvidenceForm] 🔴 Validation failed. Submission aborted.");
    }
  };

  return (
    <div>
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="mr-4 p-2 rounded-full hover:bg-gray-200 transition-colors"
          aria-label="Go back"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6 text-primary-dark"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
        </button>
        <h2 className="text-2xl font-bold text-primary-dark">
          Claim for: <span className="text-primary">{category.label}</span>
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <p className="text-sm text-gray-600">
          Please upload the required evidence. Fields marked with{" "}
          <span className="text-red-500">*</span> are mandatory. You can select
          multiple files for each category.
        </p>
        {fields.map((field) => (
          <div key={field.id}>
            <FormField field={field} onChange={handleChange} />
            {errors[field.id] && (
              <p className="text-sm text-red-500 mt-1">{errors[field.id]}</p>
            )}
          </div>
        ))}

        <div className="pt-5">
          <div className="flex justify-end">
            <button
              type="button"
              onClick={onBack}
              className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Back
            </button>
            <button
              type="submit"
              className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Review Claim
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

EvidenceForm.propTypes = {
  category: PropTypes.shape({
    id: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    policyNumber: PropTypes.string.isRequired,
  }).isRequired,
  onBack: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
};
