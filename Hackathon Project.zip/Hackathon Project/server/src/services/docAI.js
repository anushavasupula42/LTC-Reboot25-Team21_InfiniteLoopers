/**
 * @fileoverview This service interfaces with the Google Cloud Document AI API.
 * It has been refactored to include robust logging and error handling, providing
 * clear visibility into the document processing workflow.
 *
 * The main function, `extractFields`, calls a specified Document AI processor,
 * extracts structured key-value pairs (entities), and returns them along with
_**the full text of the document for further analysis (e.g., summarization).
 */
import { DocumentProcessorServiceClient } from "@google-cloud/documentai";
import { PROJECT_ID, DOC_PROCESSOR_ID } from "../util/env.js";

/* ------------------------------------------------------------------ */
/*  Initialize Client and Processor Path                              */
/* ------------------------------------------------------------------ */
console.log("[DocAI] Initializing Document AI client...");
const client = new DocumentProcessorServiceClient();

// Construct the full resource name of the processor
const name = `projects/${PROJECT_ID}/locations/us/processors/${DOC_PROCESSOR_ID}`;

console.log(
  `[DocAI] ✅ Client initialized. Using processor: ${DOC_PROCESSOR_ID}`,
);

/* ------------------------------------------------------------------ */
/*  Helper: Call Extractor and Get Structured Fields + Full Text      */
/* ------------------------------------------------------------------ */
/**
 * Processes a document buffer using a Custom Extractor processor in Document AI.
 *
 * @param {Buffer} buffer The raw document content as a buffer.
 * @param {string} mimeType The MIME type of the document (e.g., "application/pdf").
 * @returns {Promise<{fields: object, text: string}>} A promise that resolves to an
 *   object containing the extracted fields as a key-value pair and the full text.
 * @throws {Error} Throws an error if the API call fails or the response is invalid.
 */
export async function extractFields(buffer, mimeType) {
  console.log(`[DocAI] Processing document with MIME type: ${mimeType}.`);

  try {
    // 1. Call the 'Custom Extractor' processor
    console.log("[DocAI] Calling Document AI processDocument API...");
    const [result] = await client.processDocument({
      name,
      rawDocument: { content: buffer, mimeType },
    });
    console.log("[DocAI] ✅ API call successful. Analyzing response.");

    // 2. Extract the full text and entities from the response
    const { document } = result;
    if (!document || !document.entities) {
      console.warn("[DocAI] ⚠️ Document AI response did not contain entities.");
      return { fields: {}, text: document?.text || "" };
    }

    const { text, entities } = document;
    console.log(`[DocAI] Found ${entities.length} entities in the document.`);

    // 3. Convert entities into a simple { key: value } object
    const fields = {};
    for (const entity of entities) {
      const key = entity.type;
      const value = entity.mentionText.trim();
      // To handle cases where the same field is found multiple times,
      // we can decide to overwrite or append. Overwriting is simpler for now.
      fields[key] = value;
      console.log(`[DocAI]   - Extracted: { ${key}: "${value}" }`);
    }

    console.log("[DocAI] ✅ Finished parsing entities.");
    if (Object.keys(fields).length > 0) {
      console.log("[DocAI] Final extracted fields:", fields);
    } else {
      console.log("[DocAI] No key-value pairs were extracted from entities.");
    }

    // 4. Return the fields and the full text
    return { fields, text: text || "" };
  } catch (error) {
    console.error(
      "🔴 [DocAI] FATAL: An error occurred during the Document AI API call:",
      error,
    );
    // Re-throw a more specific error to be handled by the caller
    throw new Error(`Document AI processing failed: ${error.message}`);
  }
}
