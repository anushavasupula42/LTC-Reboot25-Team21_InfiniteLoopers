/**
 * @fileoverview This utility centralizes the logic for validating file MIME types.
 * It ensures that file validation rules are consistent and easy to manage.
 * The exports from this file are used by the multer configuration in
 * `routes/upload.js` to filter incoming files.
 */

/**
 * A centralized list of allowed MIME types for documents.
 * Exported for direct use in other modules.
 */
export const DOCUMENT_MIMES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // .docx
  "text/plain", // .txt
];

/**
 * The prefix used to identify all image MIME types.
 * Exported for direct use in other modules.
 */
export const IMAGE_PREFIX = "image/";

/**
 * Checks if a given MIME type is allowed by the application.
 * This function can be used for more complex validation scenarios if needed.
 *
 * @param {string} mimeType The MIME type string to validate (e.g., "application/pdf").
 * @param {'document' | 'image' | 'any'} [category='any'] - The category to check against.
 *   - 'document': Checks only against the document MIME list.
 *   - 'image': Checks only if it's an image type.
 *   - 'any': Checks against both documents and images.
 * @returns {boolean} True if the MIME type is allowed, false otherwise.
 */
export function isAllowedMime(mimeType, category = "any") {
  if (!mimeType) {
    return false;
  }

  const isDocument = DOCUMENT_MIMES.includes(mimeType);
  const isImage = mimeType.startsWith(IMAGE_PREFIX);

  switch (category) {
    case "document":
      return isDocument;
    case "image":
      return isImage;
    case "any":
    default:
      return isDocument || isImage;
  }
}
