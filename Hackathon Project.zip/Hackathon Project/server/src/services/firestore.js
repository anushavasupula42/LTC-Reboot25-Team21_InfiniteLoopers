/**
 * @fileoverview This file contains the Firestore service logic for the application.
 * It has been refactored for clarity, improved logging, and robust error handling.
 *
 * Key Functions:
 * - Initializes the Firebase Admin SDK to connect to Firestore.
 * - Exports references to the `policies` and `claims` collections.
 * - Provides the `createClaim` function, which atomically creates a new claim
 *   document and its associated evidence sub-collection in a single batch write.
 */
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { PROJECT_ID } from "../util/env.js";

/* ------------------------------------------------------------------ */
/*  Initialize Firebase Admin SDK and Firestore                       */
/* ------------------------------------------------------------------ */
console.log("[FIRESTORE] Initializing Firebase Admin SDK...");
initializeApp({
  credential: applicationDefault(),
  projectId: PROJECT_ID,
});

const db = getFirestore();
console.log("[FIRESTORE] ✅ Firebase Admin SDK initialized successfully.");

/* ------------------------------------------------------------------ */
/*  Export Firestore Collection References                            */
/* ------------------------------------------------------------------ */
export const policiesCol = db.collection("policies");
export const claimsCol = db.collection("claims");
console.log(
  "[FIRESTORE] Exporting collection references for 'policies' and 'claims'.",
);

/* ------------------------------------------------------------------ */
/*  Helper: Create a New Claim from Uploaded Evidence                 */
/* ------------------------------------------------------------------ */
/**
 * Creates a new claim document and its associated evidence sub-collection in Firestore.
 *
 * @param {object} params - The parameters for creating a claim.
 * @param {string} params.policyId - The ID of the policy this claim belongs to.
 * @param {Array<object>} [params.uploadedFiles=[]] - An array of processed file objects.
 * @returns {Promise<object>} A promise that resolves to the newly created claim data.
 * @throws {Error} Throws an error if the policy is not found or if the database write fails.
 */
export async function createClaim({ policyId, uploadedFiles = [] }) {
  console.log(`[FIRESTORE] createClaim triggered for policyId: '${policyId}'.`);

  // 1. Fetch and Validate the Policy Document
  console.log(`[FIRESTORE] Fetching policy document '${policyId}'...`);
  const policyRef = policiesCol.doc(policyId);
  const policyDoc = await policyRef.get();

  if (!policyDoc.exists) {
    const errorMessage = `Policy with ID '${policyId}' not found.`;
    console.error(`[FIRESTORE] 🔴 Validation failed: ${errorMessage}`);
    throw new Error(errorMessage);
  }
  const policyData = policyDoc.data();
  console.log(
    `[FIRESTORE] ✅ Found policy for holder: ${policyData.policyHolder}`,
  );

  // 2. Generate a New, User-Friendly Claim ID
  const claimId = `CLM${Date.now().toString().slice(-6)}`;
  const claimRef = claimsCol.doc(claimId);
  console.log(`[FIRESTORE] Generated new claim ID: ${claimId}`);

  // 3. Aggregate Data from All Uploaded Files
  console.log(
    `[FIRESTORE] Aggregating data from ${uploadedFiles.length} uploaded file(s)...`,
  );
  const allSummaries = [];
  let allFields = {};
  const evidenceForSubcollection = [];

  for (const file of uploadedFiles) {
    if (file.summary) {
      allSummaries.push(file.summary);
    }
    if (file.fields && Object.keys(file.fields).length > 0) {
      allFields = { ...allFields, ...file.fields };
    }
    evidenceForSubcollection.push({
      name: file.name,
      url: file.url,
      summary:
        file.summary || "No AI summary could be generated for this file.",
      uploadedAt: new Date(),
    });
  }
  console.log(
    `[FIRESTORE] ✅ Aggregation complete. Found ${
      Object.keys(allFields).length
    } extracted fields and ${allSummaries.length} summaries.`,
  );

  // 4. Construct the Main Claim Document
  const newClaimData = {
    id: claimId,
    policyId,
    policyHolder: policyData.policyHolder || "N/A",
    status: "Submitted",
    createdAt: new Date(),
    ...allFields,
    summary:
      allSummaries.length > 0
        ? allSummaries.join("\n\n---\n\n")
        : "No summary available.",
    // Mock fraud data as specified
    fraudDetected: false,
    redFlags: 0,
    fraudInfo: [],
  };
  console.log("[FIRESTORE] Constructed main claim document payload.");

  // 5. Use a Batch Write for an Atomic "All or Nothing" Operation
  try {
    const batch = db.batch();
    console.log("[FIRESTORE] Starting atomic batch write...");

    // Add the main claim document to the batch
    batch.set(claimRef, newClaimData);
    console.log(`[FIRESTORE]   - Batching SET for 'claims/${claimId}'`);

    // Add each piece of evidence to the 'evidence' sub-collection in the batch
    const evidenceColRef = claimRef.collection("evidence");
    for (const evidence of evidenceForSubcollection) {
      const newEvidenceRef = evidenceColRef.doc(); // Auto-generate ID for evidence doc
      batch.set(newEvidenceRef, evidence);
    }
    console.log(
      `[FIRESTORE]   - Batching SET for ${evidenceForSubcollection.length} document(s) in 'evidence' sub-collection.`,
    );

    // 6. Commit all batched writes to the database
    await batch.commit();
    console.log(
      `[FIRESTORE] ✅ Batch commit successful. Claim '${claimId}' is now in the database.`,
    );

    // 7. Return the newly created claim document to the caller
    return newClaimData;
  } catch (error) {
    console.error(
      `[FIRESTORE] 🔴🔴 FATAL: An error occurred during the Firestore batch write for claim '${claimId}':`,
      error,
    );
    // Throw a generic error to avoid leaking implementation details
    throw new Error("A database error occurred while creating the claim.");
  }
}
