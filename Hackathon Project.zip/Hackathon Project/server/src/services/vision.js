/**
 * @fileoverview This service interfaces with Google Cloud's Vertex AI API (Gemini)
 * for image analysis. It has been refactored for better logging, robust error
 * handling, and clarity.
 *
 * The main function, `summarizeImage`, takes an image buffer and uses a multimodal
 * generative model to produce a concise, single-sentence description of the image.
 */
import { VertexAI } from "@google-cloud/vertexai";
import { PROJECT_ID } from "../util/env.js";

/* ------------------------------------------------------------------ */
/*  Initialize Vertex AI Client and Generative Model                  */
/* ------------------------------------------------------------------ */
console.log("[VisionAI] Initializing Vertex AI client...");

const vertex_ai = new VertexAI({
  project: PROJECT_ID,
  location: "us-central1", // A supported Vertex AI location
});

// Use a specific Gemini model capable of multimodal input.
// "gemini-1.0-pro-vision" is a standard choice for this task.
const model = "gemini-2.5-flash";
const generativeModel = vertex_ai.getGenerativeModel({ model });

console.log(`[VisionAI] ✅ Client initialized. Using model: ${model}`);

/* ------------------------------------------------------------------ */
/*  Helper: Call Gemini to Describe an Image                          */
/* ------------------------------------------------------------------ */
/**
 * Generates a concise, one-sentence description for a given image.
 *
 * @param {Buffer} buffer The image content as a buffer.
 * @param {string} mimeType The MIME type of the image (e.g., "image/jpeg").
 * @returns {Promise<string>} A promise that resolves to the AI-generated summary
 *   or an error message on failure.
 */
export async function summarizeImage(buffer, mimeType) {
  console.log(
    `[VisionAI] summarizeImage called for image with MIME type: ${mimeType}.`,
  );

  // 1. Prepare the image data in the format required by the API
  const imagePart = {
    inlineData: {
      data: buffer.toString("base64"),
      mimeType,
    },
  };

  // 2. Define the prompt for the generative model
  const prompt =
    "Describe this image in a single, concise sentence, focusing on the main subject.";

  try {
    // 3. Construct the request payload with both text and image parts
    const request = {
      contents: [{ role: "user", parts: [{ text: prompt }, imagePart] }],
    };

    console.log(
      "[VisionAI] Calling Vertex AI generateContent API for image analysis...",
    );
    const resp = await generativeModel.generateContent(request);
    console.log("[VisionAI] ✅ API call successful. Analyzing response.");

    // 4. Safely access the response text using optional chaining
    const responseText =
      resp.response?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (responseText) {
      console.log(`[VisionAI] Generated summary: "${responseText}"`);
      return responseText;
    } else {
      console.warn(
        "[VisionAI] ⚠️ AI response was valid but contained no text content.",
      );
      return "AI summary could not be generated for this image.";
    }
  } catch (err) {
    console.error(
      "🔴 [VisionAI] FATAL: An error occurred during the Vertex AI API call for image summary:",
      err,
    );
    // Return a user-friendly error message
    return "An error occurred while generating the AI image summary.";
  }
}
