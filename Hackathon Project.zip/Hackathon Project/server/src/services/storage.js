/**
 * @fileoverview This service handles all interactions with Google Cloud Storage (GCS).
 * It has been refactored for improved logging and more resilient error handling.
 *
 * Key Functions:
 * - `uploadFile`: The main public function that takes a file object (from multer),
 *   uploads it to the configured GCS bucket, and returns a secure, temporary
 *   signed URL for accessing the file.
 * - `getSignedUrl`: An internal helper to generate time-limited read URLs for
 *   files in GCS, enhancing security by not making files publicly readable.
 */
import { Storage } from "@google-cloud/storage";
import { BUCKET_NAME } from "../util/env.js";

/* ------------------------------------------------------------------ */
/*  Initialize GCS Client and Bucket Reference                        */
/* ------------------------------------------------------------------ */
console.log("[GCS] Initializing Google Cloud Storage client...");
const storage = new Storage();
const bucket = storage.bucket(BUCKET_NAME);
console.log(`[GCS] ✅ Client initialized. Target bucket: "${BUCKET_NAME}"`);

/* ------------------------------------------------------------------ */
/*  Internal Helper: Generate a Secure, Temporary Signed URL          */
/* ------------------------------------------------------------------ */
/**
 * Generates a v4 signed URL for a file in GCS, granting temporary read access.
 *
 * @param {string} fileName The name of the file in the GCS bucket.
 * @returns {Promise<string>} A promise that resolves to the signed URL.
 * @throws {Error} Throws an error if URL generation fails.
 */
async function getSignedUrl(fileName) {
  console.log(`[GCS] Generating signed URL for file: ${fileName}`);
  // Configure the signed URL to be valid for 15 minutes
  const options = {
    version: "v4",
    action: "read",
    expires: Date.now() + 15 * 60 * 1000, // 15 minutes
  };

  try {
    const [url] = await bucket.file(fileName).getSignedUrl(options);
    console.log(`[GCS] ✅ Successfully generated signed URL for ${fileName}.`);
    return url;
  } catch (error) {
    console.error(
      `🔴 [GCS] FATAL: Could not generate signed URL for ${fileName}:`,
      error,
    );
    // Propagate the error to the calling function
    throw new Error(`Could not generate signed URL for ${fileName}.`);
  }
}

/* ------------------------------------------------------------------ */
/*  Exported Helper: Upload a File and Get a Signed URL               */
/* ------------------------------------------------------------------ */
/**
 * Uploads a file from a buffer to Google Cloud Storage and returns a secure,
 * temporary signed URL for access.
 *
 * @param {object} file The file object from multer (must contain originalname, buffer, mimetype).
 * @returns {Promise<string>} A promise that resolves to the signed URL of the uploaded file.
 * @throws {Error} Throws an error if the upload or URL generation fails.
 */
export async function uploadFile(file) {
  console.log(`[GCS] uploadFile called for: ${file.originalname}`);

  // 1. Sanitize the filename and make it unique to prevent GCS overwrites
  const sanitizedName = file.originalname
    .replace(/\s/g, "_")
    .replace(/[^\w.-]/g, "");
  const uniqueFileName = `${Date.now()}-${sanitizedName}`;
  const gcsFile = bucket.file(uniqueFileName);
  console.log(`[GCS]   - Sanitized and unique filename: ${uniqueFileName}`);

  try {
    // 2. Save the file buffer to the GCS bucket
    console.log(`[GCS] Uploading buffer to GCS for ${uniqueFileName}...`);
    await gcsFile.save(file.buffer, {
      contentType: file.mimetype,
      // For small files, setting resumable to false can be slightly faster
      // as it avoids the overhead of a resumable upload session.
      resumable: false,
    });
    console.log(
      `[GCS] ✅ Successfully uploaded ${file.originalname} to GCS as ${uniqueFileName}.`,
    );

    // 3. Return a signed URL for secure, temporary access
    return getSignedUrl(uniqueFileName);
  } catch (error) {
    console.error(
      `🔴 [GCS] FATAL: Error uploading file ${file.originalname} to GCS:`,
      error,
    );
    // Re-throw a more specific error to be handled by the route handler
    throw new Error(
      `Failed to upload file '${file.originalname}' to Cloud Storage.`,
    );
  }
}
