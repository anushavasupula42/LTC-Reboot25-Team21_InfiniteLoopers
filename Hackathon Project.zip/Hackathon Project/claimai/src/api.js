import axios from "axios";
const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:4000/api",
});

export const uploadFiles = (policyId, formData) =>
  API.post(`/upload?policyId=${policyId}`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

export const createPolicy = (policyId, files) =>
  API.post("/policies", { policyId, files });
export const listPolicies = () => API.get("/policies");
export const getPolicy = (id) => API.get(`/policies/${id}`);
export const deletePolicy = (id) => API.delete(`/policies/${id}`);

export default {
  uploadFiles,
  createPolicy,
  listPolicies,
  getPolicy,
  deletePolicy,
};
